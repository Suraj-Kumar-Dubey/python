import json
my_dict={'name':'hari','of':'asm','pack':['python','ajs','html']}
print json.dumps(my_dict,indent=18)
